<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_Blog
 */


namespace Amasty\Blog\Controller\Index;

/**
 * Class
 */
class Index extends \Amasty\Blog\Controller\AbstractController\Index
{
}

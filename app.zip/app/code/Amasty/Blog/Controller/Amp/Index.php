<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_Blog
 */


namespace Amasty\Blog\Controller\Amp;

/**
 * Class Index
 */
class Index extends \Amasty\Blog\Controller\AbstractController\Index
{
}

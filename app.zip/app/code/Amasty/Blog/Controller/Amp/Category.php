<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_Blog
 */


namespace Amasty\Blog\Controller\Amp;

/**
 * Class Category
 */
class Category extends \Amasty\Blog\Controller\AbstractController\Category
{
}

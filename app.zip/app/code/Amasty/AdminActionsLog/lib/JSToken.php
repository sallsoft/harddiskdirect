<?php

namespace Amasty\AdminActionsLog\lib;

class JSToken
{
    public $type;
    public $value;
    public $start;
    public $end;
    public $lineno;
    public $assignOp;
}
